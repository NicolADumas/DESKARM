# GUIDA: COME COLLEGARE IL PULSANTE IN POWERPOINT AL SIMULATORE

## 📌 IMPORTANTE: PowerPoint e Python

PowerPoint **NON può eseguire direttamente codice Python** durante la presentazione.
Tuttavia, ci sono diversi modi per creare un'esperienza interattiva:

---

## ✅ METODO 1: HYPERLINK A FILE BATCH/SCRIPT (RACCOMANDATO)

### Windows

1. **Apri la presentazione** in PowerPoint
2. **Vai alla Slide 4** (quella con il pulsante "AVVIA SIMULATORE")
3. **Seleziona il rettangolo del pulsante**
4. **Tasto destro** → **Collegamento ipertestuale** (oppure Ctrl+K)
5. Nella finestra che si apre:
   - Clicca su **"File o pagina Web esistente"**
   - Clicca su **"Sfoglia..."**
   - Naviga fino alla cartella del progetto
   - Seleziona `launch_robot.bat`
   - Click **OK**

6. **TESTA**: In modalità presentazione (F5), clicca sul pulsante
   - Si aprirà una finestra del prompt dei comandi
   - Il simulatore si avvierà automaticamente

### Linux/Mac

1. Segui gli stessi passi 1-5 di sopra
2. Invece di `launch_robot.bat`, seleziona `launch_robot.sh`
3. Se non funziona, rendi eseguibile lo script:
   ```bash
   chmod +x launch_robot.sh
   ```

---

## ✅ METODO 2: HYPERLINK DIRETTO AL FILE PYTHON

### Configurazione Sistema

#### Windows
1. Associa i file `.py` a Python:
   - Tasto destro su un file `.py` → **Apri con** → **Python**
   - Spunta "Usa sempre questa app per aprire i file .py"

#### Linux/Mac
1. Rendi eseguibile lo script:
   ```bash
   chmod +x robot_manipulator.py
   ```
2. Verifica che la prima riga sia: `#!/usr/bin/env python3`

### In PowerPoint

1. Seleziona il pulsante nella Slide 4
2. Tasto destro → **Collegamento ipertestuale**
3. Seleziona direttamente `robot_manipulator.py`
4. Click **OK**

---

## ✅ METODO 3: PULSANTE CON MACRO VBA (AVANZATO)

⚠️ **Richiede abilitazione delle macro in PowerPoint**

### Passo 1: Abilita Sviluppatore

1. **File** → **Opzioni** → **Personalizza barra multifunzione**
2. Spunta **Sviluppatore** nella colonna destra
3. Click **OK**

### Passo 2: Inserisci il Codice VBA

1. Nella ribbon **Sviluppatore**, click **Visual Basic**
2. Nel menù, **Inserisci** → **Modulo**
3. Incolla questo codice:

```vba
Sub LaunchRobotSimulator()
    Dim scriptPath As String
    Dim shellCommand As String
    
    ' MODIFICA QUESTO PERCORSO con il percorso completo al tuo script
    scriptPath = "C:\Users\TuoNome\Desktop\RobotProject\launch_robot.bat"
    
    ' Per Windows
    shellCommand = "cmd /c """ & scriptPath & """"
    
    ' Esegui il comando
    Shell shellCommand, vbNormalFocus
    
    ' Messaggio opzionale
    MsgBox "Simulatore avviato!", vbInformation, "Robot Manipulator"
End Sub
```

4. **IMPORTANTE**: Modifica `scriptPath` con il percorso REALE del tuo file
5. Chiudi l'editor VBA

### Passo 3: Collega la Macro al Pulsante

1. Seleziona il rettangolo del pulsante nella Slide 4
2. Tasto destro → **Azione** (o **Impostazioni azione**)
3. Nella scheda **Click del mouse**:
   - Seleziona **Esegui macro**
   - Scegli `LaunchRobotSimulator` dal menu a tendina
4. Click **OK**

### Passo 4: Salva come Presentazione Abilitata per Macro

1. **File** → **Salva con nome**
2. Tipo file: **Presentazione con attivazione macro di PowerPoint (*.pptm)**
3. Salva

### Sicurezza

Quando apri il file `.pptm`:
- PowerPoint mostrerà un avviso di sicurezza
- Click su **Abilita contenuto** per permettere l'esecuzione della macro

---

## ✅ METODO 4: LANCIO MANUALE (PIÙ SEMPLICE)

Se i metodi automatici risultano complicati:

### Durante la Presentazione:

1. **Prima di iniziare**: Lancia manualmente il simulatore
   - Doppio click su `launch_robot.bat` (Windows)
   - O esegui `python robot_manipulator.py` da terminale

2. **Lascia la finestra del simulatore aperta**

3. **Avvia la presentazione PowerPoint**

4. **Alla Slide 4**: 
   - Premi **Alt+Tab** (Windows) o **Cmd+Tab** (Mac)
   - Passa alla finestra del simulatore
   - Dimostra le funzionalità
   - Torna a PowerPoint con **Alt+Tab** / **Cmd+Tab**

**Vantaggi**:
- Nessuna configurazione complessa
- Funziona sempre
- Controllo completo sul timing

---

## 🎯 METODO CONSIGLIATO PER TIPO DI UTENTE

### Per Principianti
→ **METODO 4** (Lancio Manuale)
- Zero configurazione
- Sempre funzionante

### Per Utenti Intermedi  
→ **METODO 1** (Hyperlink a Batch)
- Setup semplice
- Funziona in presentazione
- Un click per lanciare

### Per Utenti Avanzati
→ **METODO 3** (Macro VBA)
- Integrazione completa
- Esperienza professionale
- Richiede abilitazione macro

---

## 🔍 VERIFICA FUNZIONAMENTO

### Test Preliminare:

1. **Test dello script standalone**:
   ```bash
   python robot_manipulator.py
   ```
   Deve aprirsi la finestra del simulatore.

2. **Test del batch file** (Windows):
   - Doppio click su `launch_robot.bat`
   - Deve aprirsi il prompt e poi il simulatore

3. **Test in PowerPoint**:
   - Apri la presentazione
   - Vai in modalità presentazione (F5)
   - Naviga alla Slide 4
   - Clicca sul pulsante
   - Verifica che qualcosa succeda (si apre il simulatore o appare un errore chiaro)

---

## 🐛 RISOLUZIONE PROBLEMI

### "Impossibile trovare il file"
**Causa**: Il percorso nel collegamento ipertestuale è errato  
**Soluzione**: 
1. Verifica che tutti i file siano nella stessa cartella
2. Usa percorsi ASSOLUTI (es: `C:\Users\...\launch_robot.bat`)
3. Evita spazi nei nomi delle cartelle

### Il pulsante non fa nulla
**Causa**: Collegamento non configurato  
**Soluzione**: Ripeti i passi del Metodo 1

### "Impossibile eseguire il programma"
**Causa**: Python non installato o non nel PATH  
**Soluzione**:
```bash
# Verifica installazione Python
python --version
# Se non funziona, reinstalla Python e spunta "Add to PATH"
```

### Macro non disponibile
**Causa**: File salvato come `.pptx` invece di `.pptm`  
**Soluzione**: Salva come **Presentazione con attivazione macro (.pptm)**

### Errore "ModuleNotFoundError: No module named 'PIL'"
**Soluzione**:
```bash
pip install Pillow
```

---

## 💡 SUGGERIMENTI PRO

### 1. Posizionamento Files
Metti TUTTI i file nella stessa cartella:
```
📁 Presentazione_Robot/
   ├── Presentazione_Manipolatore_Robotico.pptx
   ├── robot_manipulator.py
   ├── launch_robot.bat
   ├── launch_robot.sh
   └── README.md
```

### 2. Percorsi Relativi vs Assoluti
- **Relativi**: Funzionano se sposti l'intera cartella
- **Assoluti**: `C:\Users\Nome\Desktop\...` (specifici per quel computer)

### 3. Presentazione Portable
Per presentare su computer diversi:
1. Usa il **Metodo 4** (lancio manuale)
2. Oppure usa percorsi relativi
3. Porta tutti i file su USB

### 4. Durante la Demo
1. **Testa TUTTO prima** della presentazione vera
2. Chiudi programmi non necessari
3. Disabilita notifiche
4. Prepara immagini semplici per il processing

---

## 📋 CHECKLIST PRE-PRESENTAZIONE

- [ ] Python installato e funzionante
- [ ] Pillow installato (`pip install Pillow`)
- [ ] Script testato standalone
- [ ] Batch/shell script testato
- [ ] Collegamento pulsante verificato
- [ ] Test in modalità presentazione
- [ ] Immagini preparate per processing (opzionale)
- [ ] README a portata di mano per emergenze

---

## 🎬 SCRIPT PER LA PRESENTAZIONE

Quando arrivi alla **Slide 4**:

> "Ora vi mostrerò il simulatore in azione. [Click sul pulsante o Alt+Tab]
> Come potete vedere, abbiamo un manipolatore robotico a 2 gradi di libertà.
> Posso controllarlo manualmente con questi slider... [muovi θ1 e θ2]
> Oppure posso usare la cinematica inversa... [click su punti del canvas]
> Abilito la tracciatura e disegno liberamente... [abilita traccia, click vari punti]
> O posso far eseguire animazioni preset... [click 'Disegna Cerchio']
> E persino tracciare immagini... [carica immagine, traccia contorni]"

---

**Pronto per la tua presentazione interattiva! 🚀**
