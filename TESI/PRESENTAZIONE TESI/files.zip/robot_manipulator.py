#!/usr/bin/env python3
"""
Simulatore interattivo di manipolatore robotico a 2 gradi di libertà
con capacità di disegno, scrittura e processing immagini
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import math
import json
from PIL import Image, ImageTk, ImageDraw
import sys

class RobotManipulator2DOF:
    """Classe per gestire la cinematica del manipolatore a 2 DOF"""
    
    def __init__(self, l1=150, l2=120):
        """
        Inizializza il manipolatore
        l1: lunghezza primo link (pixel)
        l2: lunghezza secondo link (pixel)
        """
        self.l1 = l1
        self.l2 = l2
        self.theta1 = 0  # Angolo primo giunto (radianti)
        self.theta2 = 0  # Angolo secondo giunto (radianti)
        
    def forward_kinematics(self):
        """Calcola la posizione dell'end effector date gli angoli"""
        # Posizione giunto 1
        x1 = self.l1 * math.cos(self.theta1)
        y1 = self.l1 * math.sin(self.theta1)
        
        # Posizione end effector
        x2 = x1 + self.l2 * math.cos(self.theta1 + self.theta2)
        y2 = y1 + self.l2 * math.sin(self.theta1 + self.theta2)
        
        return (x1, y1), (x2, y2)
    
    def inverse_kinematics(self, target_x, target_y):
        """Calcola gli angoli necessari per raggiungere una posizione target"""
        d = math.sqrt(target_x**2 + target_y**2)
        
        # Verifica se il target è raggiungibile
        if d > (self.l1 + self.l2) or d < abs(self.l1 - self.l2):
            return None
        
        # Calcola theta2 usando la legge dei coseni
        cos_theta2 = (d**2 - self.l1**2 - self.l2**2) / (2 * self.l1 * self.l2)
        cos_theta2 = max(-1, min(1, cos_theta2))  # Clamp tra -1 e 1
        theta2 = math.acos(cos_theta2)
        
        # Calcola theta1
        alpha = math.atan2(target_y, target_x)
        beta = math.atan2(self.l2 * math.sin(theta2), self.l1 + self.l2 * math.cos(theta2))
        theta1 = alpha - beta
        
        return theta1, theta2


class RobotSimulatorGUI:
    """Interfaccia grafica per il simulatore del manipolatore"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Simulatore Manipolatore 2-DOF - Controllo Disegno e Scrittura")
        self.root.geometry("1400x900")
        
        # Inizializza il robot
        self.robot = RobotManipulator2DOF(l1=150, l2=120)
        
        # Modalità operative
        self.mode = tk.StringVar(value="manual")
        self.drawing_enabled = tk.BooleanVar(value=False)
        self.trail_points = []
        
        # Immagine caricata per processing
        self.loaded_image = None
        self.image_contours = []
        
        # Setup GUI
        self.setup_gui()
        
        # Animazione
        self.animating = False
        self.animation_path = []
        self.animation_index = 0
        
        # Disegna il robot iniziale
        self.update_visualization()
        
    def setup_gui(self):
        """Configura l'interfaccia grafica"""
        
        # Frame principale diviso in 3 colonne
        left_frame = ttk.Frame(self.root, padding="10")
        left_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        center_frame = ttk.Frame(self.root, padding="10")
        center_frame.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        right_frame = ttk.Frame(self.root, padding="10")
        right_frame.grid(row=0, column=2, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure(0, weight=1)
        
        # ===== PANNELLO SINISTRO - CONTROLLI =====
        ttk.Label(left_frame, text="CONTROLLO MANIPOLATORE", 
                 font=("Arial", 14, "bold")).pack(pady=10)
        
        # Slider per Theta1
        ttk.Label(left_frame, text="θ1 (Giunto Base):", 
                 font=("Arial", 10)).pack(anchor=tk.W)
        self.theta1_var = tk.DoubleVar(value=0)
        theta1_slider = ttk.Scale(left_frame, from_=-180, to=180, 
                                  variable=self.theta1_var, 
                                  command=self.on_slider_change,
                                  orient=tk.HORIZONTAL, length=250)
        theta1_slider.pack(fill=tk.X, pady=5)
        self.theta1_label = ttk.Label(left_frame, text="0.0°")
        self.theta1_label.pack(anchor=tk.W)
        
        # Slider per Theta2
        ttk.Label(left_frame, text="θ2 (Giunto Gomito):", 
                 font=("Arial", 10)).pack(anchor=tk.W, pady=(15, 0))
        self.theta2_var = tk.DoubleVar(value=0)
        theta2_slider = ttk.Scale(left_frame, from_=-180, to=180, 
                                  variable=self.theta2_var,
                                  command=self.on_slider_change,
                                  orient=tk.HORIZONTAL, length=250)
        theta2_slider.pack(fill=tk.X, pady=5)
        self.theta2_label = ttk.Label(left_frame, text="0.0°")
        self.theta2_label.pack(anchor=tk.W)
        
        # Separatore
        ttk.Separator(left_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=20)
        
        # Controlli di disegno
        ttk.Label(left_frame, text="MODALITÀ DISEGNO", 
                 font=("Arial", 12, "bold")).pack(pady=10)
        
        self.draw_btn = ttk.Checkbutton(left_frame, text="Abilita Tracciatura", 
                                       variable=self.drawing_enabled,
                                       command=self.toggle_drawing)
        self.draw_btn.pack(pady=5)
        
        ttk.Button(left_frame, text="Pulisci Traccia", 
                  command=self.clear_trail).pack(pady=5)
        
        ttk.Button(left_frame, text="Salva Disegno", 
                  command=self.save_drawing).pack(pady=5)
        
        # Separatore
        ttk.Separator(left_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=20)
        
        # Modalità automatiche
        ttk.Label(left_frame, text="ANIMAZIONI", 
                 font=("Arial", 12, "bold")).pack(pady=10)
        
        ttk.Button(left_frame, text="Scrivi 'CIAO'", 
                  command=lambda: self.animate_writing("CIAO")).pack(pady=5)
        
        ttk.Button(left_frame, text="Disegna Cerchio", 
                  command=self.animate_circle).pack(pady=5)
        
        ttk.Button(left_frame, text="Disegna Quadrato", 
                  command=self.animate_square).pack(pady=5)
        
        ttk.Button(left_frame, text="Stop Animazione", 
                  command=self.stop_animation).pack(pady=5)
        
        # ===== PANNELLO CENTRALE - CANVAS VISUALIZZAZIONE =====
        ttk.Label(center_frame, text="VISUALIZZAZIONE MANIPOLATORE", 
                 font=("Arial", 14, "bold")).pack(pady=10)
        
        self.canvas = tk.Canvas(center_frame, width=700, height=700, 
                               bg='white', highlightthickness=2, 
                               highlightbackground="gray")
        self.canvas.pack(expand=True, fill=tk.BOTH)
        
        # Bind click per controllo inverso
        self.canvas.bind("<Button-1>", self.on_canvas_click)
        
        # Info posizione
        self.pos_label = ttk.Label(center_frame, 
                                   text="Posizione End Effector: (0, 0)", 
                                   font=("Arial", 10))
        self.pos_label.pack(pady=5)
        
        # ===== PANNELLO DESTRO - IMAGE PROCESSING =====
        ttk.Label(right_frame, text="IMAGE PROCESSING", 
                 font=("Arial", 14, "bold")).pack(pady=10)
        
        ttk.Button(right_frame, text="Carica Immagine", 
                  command=self.load_image).pack(pady=5)
        
        ttk.Button(right_frame, text="Traccia Contorni", 
                  command=self.trace_contours).pack(pady=5)
        
        ttk.Button(right_frame, text="Esegui Tracciato", 
                  command=self.execute_contour_trace).pack(pady=5)
        
        # Canvas per preview immagine
        self.image_canvas = tk.Canvas(right_frame, width=300, height=300, 
                                     bg='lightgray')
        self.image_canvas.pack(pady=10)
        
        # Info
        info_text = """
ISTRUZIONI:
• Usa gli slider per controllare gli angoli
• Click sul canvas per controllo inverso
• Abilita tracciatura per disegnare
• Carica immagini per tracciarle
• Usa le animazioni preset
        """
        ttk.Label(right_frame, text=info_text, 
                 justify=tk.LEFT, font=("Arial", 9)).pack(pady=20)
        
    def on_slider_change(self, event=None):
        """Aggiorna il robot quando gli slider cambiano"""
        self.robot.theta1 = math.radians(self.theta1_var.get())
        self.robot.theta2 = math.radians(self.theta2_var.get())
        
        self.theta1_label.config(text=f"{self.theta1_var.get():.1f}°")
        self.theta2_label.config(text=f"{self.theta2_var.get():.1f}°")
        
        self.update_visualization()
        
    def update_visualization(self):
        """Ridisegna il robot sul canvas"""
        self.canvas.delete("all")
        
        # Centro del canvas
        cx, cy = 350, 600
        
        # Calcola posizioni
        (x1, y1), (x2, y2) = self.robot.forward_kinematics()
        
        # Converti a coordinate canvas (Y invertito)
        canvas_x1 = cx + x1
        canvas_y1 = cy - y1
        canvas_x2 = cx + x2
        canvas_y2 = cy - y2
        
        # Griglia di riferimento
        for i in range(-300, 301, 50):
            self.canvas.create_line(cx + i, cy - 300, cx + i, cy + 300, 
                                   fill='lightgray', dash=(2, 2))
            self.canvas.create_line(cx - 300, cy - i, cx + 300, cy - i, 
                                   fill='lightgray', dash=(2, 2))
        
        # Assi principali
        self.canvas.create_line(cx - 300, cy, cx + 300, cy, 
                               fill='gray', width=2)
        self.canvas.create_line(cx, cy - 300, cx, cy + 300, 
                               fill='gray', width=2)
        
        # Disegna la traccia se abilitata
        if len(self.trail_points) > 1:
            for i in range(len(self.trail_points) - 1):
                x1_t, y1_t = self.trail_points[i]
                x2_t, y2_t = self.trail_points[i + 1]
                self.canvas.create_line(x1_t, y1_t, x2_t, y2_t, 
                                       fill='blue', width=2)
        
        # Base del robot
        self.canvas.create_oval(cx - 10, cy - 10, cx + 10, cy + 10, 
                               fill='darkred', outline='black', width=2)
        
        # Link 1
        self.canvas.create_line(cx, cy, canvas_x1, canvas_y1, 
                               fill='darkblue', width=8)
        
        # Giunto 1
        self.canvas.create_oval(canvas_x1 - 8, canvas_y1 - 8, 
                               canvas_x1 + 8, canvas_y1 + 8, 
                               fill='orange', outline='black', width=2)
        
        # Link 2
        self.canvas.create_line(canvas_x1, canvas_y1, canvas_x2, canvas_y2, 
                               fill='darkgreen', width=8)
        
        # End effector
        self.canvas.create_oval(canvas_x2 - 10, canvas_y2 - 10, 
                               canvas_x2 + 10, canvas_y2 + 10, 
                               fill='red', outline='black', width=2)
        
        # Aggiungi punto alla traccia se abilitato
        if self.drawing_enabled.get():
            self.trail_points.append((canvas_x2, canvas_y2))
        
        # Aggiorna label posizione
        self.pos_label.config(text=f"Posizione End Effector: ({x2:.1f}, {y2:.1f})")
        
    def on_canvas_click(self, event):
        """Gestisce il click sul canvas per cinematica inversa"""
        cx, cy = 350, 600
        
        # Converti coordinate canvas a coordinate robot
        target_x = event.x - cx
        target_y = cy - event.y
        
        # Calcola cinematica inversa
        result = self.robot.inverse_kinematics(target_x, target_y)
        
        if result:
            theta1, theta2 = result
            self.theta1_var.set(math.degrees(theta1))
            self.theta2_var.set(math.degrees(theta2))
            self.robot.theta1 = theta1
            self.robot.theta2 = theta2
            self.update_visualization()
        else:
            messagebox.showwarning("Posizione Non Raggiungibile", 
                                  "Il target è fuori dalla workspace del robot!")
    
    def toggle_drawing(self):
        """Abilita/disabilita la tracciatura"""
        if self.drawing_enabled.get():
            self.trail_points = []
    
    def clear_trail(self):
        """Pulisce la traccia"""
        self.trail_points = []
        self.update_visualization()
    
    def save_drawing(self):
        """Salva il disegno come immagine"""
        if not self.trail_points:
            messagebox.showinfo("Info", "Nessuna traccia da salvare!")
            return
        
        # Crea immagine
        img = Image.new('RGB', (700, 700), 'white')
        draw = ImageDraw.Draw(img)
        
        # Disegna la traccia
        if len(self.trail_points) > 1:
            draw.line(self.trail_points, fill='blue', width=3)
        
        # Salva
        filename = filedialog.asksaveasfilename(defaultextension=".png",
                                                filetypes=[("PNG", "*.png")])
        if filename:
            img.save(filename)
            messagebox.showinfo("Salvato", f"Disegno salvato in {filename}")
    
    def animate_circle(self):
        """Anima il robot per disegnare un cerchio"""
        self.clear_trail()
        self.drawing_enabled.set(True)
        
        # Genera punti del cerchio
        radius = 80
        center_x, center_y = 100, 100
        steps = 60
        
        self.animation_path = []
        for i in range(steps + 1):
            angle = 2 * math.pi * i / steps
            x = center_x + radius * math.cos(angle)
            y = center_y + radius * math.sin(angle)
            self.animation_path.append((x, y))
        
        self.animation_index = 0
        self.animating = True
        self.animate_step()
    
    def animate_square(self):
        """Anima il robot per disegnare un quadrato"""
        self.clear_trail()
        self.drawing_enabled.set(True)
        
        # Genera punti del quadrato
        side = 120
        center_x, center_y = 100, 100
        
        self.animation_path = [
            (center_x - side/2, center_y - side/2),
            (center_x + side/2, center_y - side/2),
            (center_x + side/2, center_y + side/2),
            (center_x - side/2, center_y + side/2),
            (center_x - side/2, center_y - side/2)
        ]
        
        # Interpola tra i punti
        interpolated = []
        for i in range(len(self.animation_path) - 1):
            x1, y1 = self.animation_path[i]
            x2, y2 = self.animation_path[i + 1]
            for t in range(15):
                ratio = t / 15
                x = x1 + (x2 - x1) * ratio
                y = y1 + (y2 - y1) * ratio
                interpolated.append((x, y))
        
        self.animation_path = interpolated
        self.animation_index = 0
        self.animating = True
        self.animate_step()
    
    def animate_writing(self, text):
        """Anima il robot per scrivere testo (versione semplificata)"""
        self.clear_trail()
        self.drawing_enabled.set(True)
        
        # Genera punti per scrivere "CIAO" in modo stilizzato
        self.animation_path = []
        
        # C
        for i in range(20):
            angle = math.pi * 1.5 * i / 20 + math.pi/4
            x = 50 + 30 * math.cos(angle)
            y = 100 + 30 * math.sin(angle)
            self.animation_path.append((x, y))
        
        self.animation_path.append((None, None))  # Solleva penna
        
        # I
        self.animation_path.append((110, 70))
        self.animation_path.append((110, 130))
        
        self.animation_path.append((None, None))
        
        # A
        self.animation_path.append((140, 130))
        self.animation_path.append((155, 70))
        self.animation_path.append((170, 130))
        self.animation_path.append((145, 100))
        self.animation_path.append((165, 100))
        
        self.animation_path.append((None, None))
        
        # O
        for i in range(21):
            angle = 2 * math.pi * i / 20
            x = 210 + 25 * math.cos(angle)
            y = 100 + 30 * math.sin(angle)
            self.animation_path.append((x, y))
        
        self.animation_index = 0
        self.animating = True
        self.animate_step()
    
    def animate_step(self):
        """Esegue un passo dell'animazione"""
        if not self.animating or self.animation_index >= len(self.animation_path):
            self.animating = False
            return
        
        target = self.animation_path[self.animation_index]
        
        if target[0] is None:  # Solleva penna
            self.drawing_enabled.set(False)
            self.animation_index += 1
            self.root.after(100, self.animate_step)
            return
        
        self.drawing_enabled.set(True)
        
        result = self.robot.inverse_kinematics(target[0], target[1])
        if result:
            theta1, theta2 = result
            self.theta1_var.set(math.degrees(theta1))
            self.theta2_var.set(math.degrees(theta2))
            self.robot.theta1 = theta1
            self.robot.theta2 = theta2
            self.update_visualization()
        
        self.animation_index += 1
        self.root.after(50, self.animate_step)
    
    def stop_animation(self):
        """Ferma l'animazione corrente"""
        self.animating = False
    
    def load_image(self):
        """Carica un'immagine per il processing"""
        filename = filedialog.askopenfilename(
            filetypes=[("Immagini", "*.png *.jpg *.jpeg *.gif *.bmp")])
        
        if filename:
            try:
                self.loaded_image = Image.open(filename)
                # Ridimensiona per preview
                self.loaded_image.thumbnail((280, 280))
                
                # Mostra preview
                self.image_tk = ImageTk.PhotoImage(self.loaded_image)
                self.image_canvas.delete("all")
                self.image_canvas.create_image(150, 150, image=self.image_tk)
                
                messagebox.showinfo("Successo", "Immagine caricata!")
            except Exception as e:
                messagebox.showerror("Errore", f"Impossibile caricare l'immagine: {e}")
    
    def trace_contours(self):
        """Estrae i contorni dall'immagine (versione semplificata)"""
        if not self.loaded_image:
            messagebox.showwarning("Attenzione", "Carica prima un'immagine!")
            return
        
        # Converti in scala di grigi e rileva bordi (semplificato)
        img_gray = self.loaded_image.convert('L')
        width, height = img_gray.size
        
        # Trova punti con cambio di intensità significativo (edge detection semplificato)
        self.image_contours = []
        pixels = img_gray.load()
        
        threshold = 100
        step = 3
        
        for y in range(0, height - step, step):
            for x in range(0, width - step, step):
                if abs(pixels[x, y] - pixels[x + step, y]) > threshold or \
                   abs(pixels[x, y] - pixels[x, y + step]) > threshold:
                    # Scala coordinate all'area di lavoro del robot
                    robot_x = (x / width) * 200 - 100
                    robot_y = (y / height) * 200 - 100
                    self.image_contours.append((robot_x, robot_y))
        
        messagebox.showinfo("Contorni", f"Trovati {len(self.image_contours)} punti!")
    
    def execute_contour_trace(self):
        """Esegue il tracciamento dei contorni"""
        if not self.image_contours:
            messagebox.showwarning("Attenzione", "Calcola prima i contorni!")
            return
        
        self.clear_trail()
        self.drawing_enabled.set(True)
        self.animation_path = self.image_contours
        self.animation_index = 0
        self.animating = True
        self.animate_step()


def main():
    root = tk.Tk()
    app = RobotSimulatorGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
