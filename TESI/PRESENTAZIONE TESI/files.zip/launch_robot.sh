#!/bin/bash
# Launcher per il simulatore del manipolatore robotico
# Questo file può essere chiamato direttamente da PowerPoint su Linux/Mac

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
python3 "$SCRIPT_DIR/robot_manipulator.py"
