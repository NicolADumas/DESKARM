@echo off
REM Launcher per il simulatore del manipolatore robotico
REM Questo file può essere chiamato direttamente da PowerPoint

python "%~dp0robot_manipulator.py"
pause
