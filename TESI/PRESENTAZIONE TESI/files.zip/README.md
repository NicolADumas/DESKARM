# 🤖 SIMULATORE MANIPOLATORE ROBOTICO 2-DOF
## Presentazione PowerPoint Interattiva con Simulazione Python

---

## 📋 CONTENUTO DEL PACCHETTO

Questo pacchetto contiene una presentazione PowerPoint completamente funzionale con simulatore interattivo di un manipolatore robotico a 2 gradi di libertà.

### File Inclusi:

1. **Presentazione_Manipolatore_Robotico.pptx** - Presentazione PowerPoint principale
2. **robot_manipulator.py** - Script Python del simulatore interattivo
3. **launch_robot.bat** - Launcher per Windows
4. **launch_robot.sh** - Launcher per Linux/Mac
5. **README.md** - Questo file

---

## 🚀 COME USARE LA PRESENTAZIONE

### Metodo 1: Durante la Presentazione (CONSIGLIATO)

1. **Apri la presentazione** in PowerPoint
2. **Vai in modalità presentazione** (F5 o "Presentazione" → "Dall'inizio")
3. **Nella Slide 4** troverai il pulsante "AVVIA SIMULATORE"
4. **Esci temporaneamente dalla presentazione** (ESC)
5. **Lancia il simulatore**:
   - **Windows**: Doppio click su `launch_robot.bat`
   - **Linux/Mac**: Doppio click su `launch_robot.sh` o esegui da terminale: `./launch_robot.sh`
6. **Il simulatore si aprirà** in una finestra separata
7. **Riprendi la presentazione** mentre il simulatore è in esecuzione

### Metodo 2: Lancio Manuale

Puoi anche lanciare il simulatore prima di iniziare la presentazione:

```bash
# Da terminale/prompt dei comandi:
python robot_manipulator.py
```

---

## 🎮 FUNZIONALITÀ DEL SIMULATORE

### Pannello di Controllo (Sinistra)

#### 🔧 Controllo Manuale
- **Slider θ1 (Giunto Base)**: Controlla la rotazione del primo link (range: -180° a +180°)
- **Slider θ2 (Giunto Gomito)**: Controlla la rotazione del secondo link (range: -180° a +180°)

#### ✏️ Modalità Disegno
- **Abilita Tracciatura**: Attiva/disattiva la registrazione del percorso dell'end-effector
- **Pulisci Traccia**: Cancella tutti i punti tracciati
- **Salva Disegno**: Esporta il disegno come immagine PNG

#### 🎬 Animazioni Automatiche
- **Scrivi 'CIAO'**: Il robot scrive la parola "CIAO" in modo stilizzato
- **Disegna Cerchio**: Traccia un cerchio perfetto
- **Disegna Quadrato**: Traccia un quadrato
- **Stop Animazione**: Ferma l'animazione in corso

### Canvas Centrale

#### 🖱️ Controllo con Mouse (Cinematica Inversa)
- **Click sinistro** in qualsiasi punto del canvas
- Il robot calcolerà automaticamente gli angoli necessari (θ1, θ2) per raggiungere quel punto
- Se il punto è fuori dalla workspace, riceverai un avviso

#### 📊 Visualizzazione
- **Griglia di riferimento**: Sistema di coordinate con assi X e Y
- **Base del robot** (punto rosso scuro): Posizione fissa del giunto base
- **Link 1** (blu scuro): Primo braccio del robot
- **Giunto intermedio** (arancione): Giunto "gomito"
- **Link 2** (verde scuro): Secondo braccio del robot
- **End-effector** (rosso): Punto terminale che esegue i compiti
- **Traccia blu**: Percorso tracciato quando il disegno è abilitato

### Pannello Image Processing (Destra)

#### 🖼️ Processing Immagini
1. **Carica Immagine**: Importa un'immagine (PNG, JPG, GIF, BMP)
2. **Traccia Contorni**: Analizza l'immagine e identifica i bordi
3. **Esegui Tracciato**: Il robot traccia i contorni rilevati

---

## 🎓 CONCETTI DIMOSTRATI

### 1. Cinematica Diretta
**Input**: Angoli θ1 e θ2  
**Output**: Posizione (x, y) dell'end-effector

Formule utilizzate:
```
x = L1·cos(θ1) + L2·cos(θ1 + θ2)
y = L1·sin(θ1) + L2·sin(θ1 + θ2)
```

Dove:
- L1 = 150 pixel (lunghezza primo link)
- L2 = 120 pixel (lunghezza secondo link)

### 2. Cinematica Inversa
**Input**: Posizione target (x, y)  
**Output**: Angoli θ1 e θ2 necessari

Metodo:
1. Calcolo di θ2 usando la legge dei coseni
2. Calcolo di θ1 usando trigonometria
3. Verifica che il target sia raggiungibile (dentro la workspace)

### 3. Workspace del Robot
L'area raggiungibile è determinata da:
- **Raggio massimo**: L1 + L2 = 270 pixel
- **Raggio minimo**: |L1 - L2| = 30 pixel
- **Forma**: Anello circolare centrato sulla base

---

## 💡 ESEMPI DI UTILIZZO

### Esempio 1: Disegno Libero
1. Abilita "Tracciatura"
2. Clicca su vari punti del canvas per muovere il robot
3. Il robot traccerà una linea continua
4. Salva il risultato con "Salva Disegno"

### Esempio 2: Animazione Scrittura
1. Click su "Scrivi 'CIAO'"
2. Osserva il robot mentre scrive ogni lettera
3. La traccia rimane visibile al termine

### Esempio 3: Processing Immagine
1. Prepara un'immagine semplice (logo, disegno al tratto)
2. Click "Carica Immagine"
3. Click "Traccia Contorni" per l'analisi
4. Click "Esegui Tracciato" per vedere il robot riprodurla

---

## 🛠️ REQUISITI TECNICI

### Python
- **Versione**: Python 3.7 o superiore
- **Librerie richieste**:
  - `tkinter` (incluso con Python)
  - `Pillow` (PIL)
  
Installa le dipendenze:
```bash
pip install Pillow
```

### PowerPoint
- Microsoft PowerPoint 2016 o superiore
- LibreOffice Impress (alternativa open-source)

---

## 🔧 RISOLUZIONE PROBLEMI

### Il simulatore non si avvia
**Problema**: "python: command not found"  
**Soluzione**: 
- Windows: Installa Python da python.org
- Linux: `sudo apt install python3`
- Mac: `brew install python3`

### Errore "No module named 'PIL'"
**Soluzione**:
```bash
pip install Pillow
```

### Il pulsante in PowerPoint non funziona
**Spiegazione**: PowerPoint non può eseguire direttamente codice Python durante la presentazione.  
**Soluzione**: Lancia manualmente il simulatore come descritto nella sezione "COME USARE"

### Finestra troppo piccola/grande
**Soluzione**: La finestra è dimensionata a 1400x900. Puoi ridimensionarla manualmente trascinando i bordi.

---

## 📚 STRUTTURA DEL CODICE

### Classe `RobotManipulator2DOF`
Gestisce la matematica del robot:
- `forward_kinematics()`: Calcola posizione da angoli
- `inverse_kinematics()`: Calcola angoli da posizione

### Classe `RobotSimulatorGUI`
Gestisce l'interfaccia grafica:
- `setup_gui()`: Crea l'interfaccia
- `update_visualization()`: Ridisegna il robot
- `on_canvas_click()`: Gestisce il controllo inverso
- `animate_*()`: Funzioni di animazione

---

## 🎯 APPLICAZIONI REALI

I manipolatori a 2-DOF sono usati in:

1. **Industria manifatturiera**
   - Pick and place di componenti
   - Assembly di piccole parti

2. **Laboratori**
   - Manipolazione di campioni
   - Dispensing di liquidi

3. **Arte e intrattenimento**
   - Plotter artistici
   - Robot disegnatori

4. **Educazione**
   - Insegnamento di robotica
   - Dimostrazione di cinematica

5. **Prototipazione**
   - Testing di algoritmi di controllo
   - Sviluppo di sistemi più complessi

---

## 🔮 POSSIBILI ESTENSIONI

### Per studenti avanzati:
1. **Aggiungere un terzo giunto** (3-DOF)
2. **Implementare planning di traiettorie** (A*, RRT)
3. **Aggiungere rilevamento collisioni**
4. **Simulare dinamica** (forze, velocità)
5. **Controllo PID** per movimento smooth
6. **Integrazione con robot fisico** (Arduino, Raspberry Pi)

---

## 📖 CONTENUTO DELLA PRESENTAZIONE

### Slide 1: Titolo
Introduzione al sistema

### Slide 2: Introduzione
Cos'è un manipolatore 2-DOF e sue caratteristiche

### Slide 3: Cinematica
Spiegazione di cinematica diretta e inversa con formule

### Slide 4: Demo Interattiva ⭐
**PUNTO CHIAVE**: Qui lanci il simulatore durante la presentazione

### Slide 5: Applicazioni
Casi d'uso del simulatore

### Slide 6: Conclusioni
Riepilogo e chiusura

---

## 📝 NOTE IMPORTANTI

### Durante la Presentazione:
1. La **Slide 4** è il momento chiave per la dimostrazione pratica
2. Puoi **lasciare il simulatore aperto** mentre presenti
3. Alterna tra PowerPoint e simulatore per mostrare i concetti
4. Usa le **animazioni preset** per impressionare il pubblico

### Per Demo Live:
1. Pre-testa tutte le funzionalità prima della presentazione
2. Prepara immagini semplici per il processing
3. Considera di pre-caricare il simulatore prima di iniziare
4. Tieni aperto questo README per riferimento veloce

---

## 🎨 PERSONALIZZAZIONE

### Modificare i Parametri del Robot
Nel file `robot_manipulator.py`, linea ~24:

```python
self.robot = RobotManipulator2DOF(l1=150, l2=120)
```

Cambia `l1` e `l2` per diversi rapporti di lunghezza

### Cambiare Colori
Nel codice cerca le sezioni con commenti `# Colori` per modificare palette

### Aggiungere Animazioni
Crea nuove funzioni `animate_*()` seguendo gli esempi esistenti

---

## 📞 SUPPORTO

Per problemi o domande:
1. Verifica la sezione "RISOLUZIONE PROBLEMI"
2. Controlla che tutte le dipendenze siano installate
3. Testa il simulatore standalone prima di usarlo in presentazione

---

## 📜 LICENZA

Questo codice è fornito per scopi educativi.
Liberamente modificabile e distribuibile.

---

## ✨ CREDITI

Sviluppato come strumento educativo per l'insegnamento di:
- Cinematica robotica
- Controllo di sistemi meccanici
- Integrazione software-presentazioni

---

**Buona presentazione! 🚀🤖**
